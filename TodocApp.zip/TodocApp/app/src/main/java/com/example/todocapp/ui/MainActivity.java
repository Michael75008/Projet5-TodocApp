package com.example.todocapp.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.todocapp.R;
import com.example.todocapp.models.Task;
import com.example.todocapp.todolist.TaskAdapter;
import com.example.todocapp.todolist.TaskViewModel;

public class MainActivity extends AppCompatActivity implements TaskAdapter.Listener {

    private TaskViewModel taskViewModel;
    private TaskAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onClickDeleteButton(int position) {
        Task task = ;
    }
}