package com.example.todocapp.repositories;

import androidx.lifecycle.LiveData;

import com.example.todocapp.database.dao.ProjectDao;

public class ProjectDataRepository {

    private final ProjectDao projectDao;

    public ProjectDataRepository(ProjectDao projectDao) {
        this.projectDao = projectDao;
    }
}
