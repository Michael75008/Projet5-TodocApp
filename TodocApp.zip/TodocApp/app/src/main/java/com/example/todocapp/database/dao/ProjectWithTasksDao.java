package com.example.todocapp.database.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

import com.example.todocapp.models.ProjectWithTasks;

import java.util.List;

@Dao
public interface ProjectWithTasksDao {

    @Transaction
    @Query("SELECT * FROM Project")
    public List<ProjectWithTasks> getProjectsWithTasks();
}
