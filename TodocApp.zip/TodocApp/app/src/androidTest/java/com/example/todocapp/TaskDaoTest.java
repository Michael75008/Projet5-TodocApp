package com.example.todocapp;

import android.arch.core.executor.testing.InstantTaskExecutorRule;
import android.arch.persistence.room.Room;
import android.content.Context;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.todocapp.database.dao.SaveMyTaskDatabase;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class TaskDaoTest {

    private SaveMyTaskDatabase database;

    @Rule
    public InstantTaskExecutorRule instantTaskExecutorRule = new InstantTaskExecutorRule();

    @Before
    public void initDb() throws Exception {
        this.database =
                Room.inMemoryDatabaseBuilder(InstrumentationRegistry.getInstrumentation().getContext(), SaveMyTaskDatabase.class)
                        .allowMainThreadQueries()
                        .build();
    }

    @After
    public void closeDb() throws Exception {
        database.close();
    }
}