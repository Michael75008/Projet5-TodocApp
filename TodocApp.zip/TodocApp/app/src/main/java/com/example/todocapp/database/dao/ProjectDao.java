package com.example.todocapp.database.dao;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;
import android.database.Cursor;

import com.example.todocapp.models.ProjectWithTasks;

import java.util.List;

@Dao
public interface ProjectDao {

    @Query("SELECT * FROM Project")
    Cursor getProjects();
}
