package com.example.todocapp.models;

import android.arch.persistence.room.Embedded;
import android.arch.persistence.room.Relation;

import java.util.List;

public class ProjectWithTasks {
    @Embedded public Project project;
    @Relation(
            parentColumn = "projectId",
            entityColumn = "projectId"
    )
    public List<Task> tasks;
}
